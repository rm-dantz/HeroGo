﻿using UnityEngine;
using System.Collections;

public class StageLabel : MonoBehaviour {

	int current_stage;
	int new_stage;
	public Vector3 LabelPos;
	float speed = 5f;
	float maxiamDistance;
	// Use this for initialization
	void Awake() 
	{
		//current_stage = 0;
		//LabelPos = new Vector3 (4f, -2.6f, 0f);
		maxiamDistance = gameObject.transform.position.x - 15;
	}

	void Update()
	{
		//new_stage = StageManager.GetInstance ().Stage_Level;
		//Debug.Log ("current " + current_stage);
		//Debug.Log ("new " + new_stage);
		//if(current_stage != new_stage)
		//{
		//	Debug.Log ("diffrent");
		//	Instantiate(this.gameObject, LabelPos,  Quaternion.identity);
		//	current_stage = new_stage;
		//}

		float move = speed * Time.deltaTime;
		gameObject.transform.Translate(Vector3.left * move, Space.World);
		if (transform.position.x < maxiamDistance)
		{
			Destroy(this.gameObject);
		}  
	}
}
