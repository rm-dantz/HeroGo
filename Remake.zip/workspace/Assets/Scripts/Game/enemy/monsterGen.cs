﻿using UnityEngine;
using System.Collections;

public class monsterGen : MonoBehaviour {

	public Transform spawnPos;
	public GameObject monsterFrame;

	monsterData data;
	monsterDataLoad mData;

	public void Init(){
		mData= new monsterDataLoad(); 
		mData.Load ();
		//Debug.Log ("plz open");
	}

	public void Gen(int Id){

		data = new monsterData(mData.CreateMonster (Id));
		GameObject monster = new GameObject ();
		monster.name = data.mName;
		monster.tag = "Enemy";
		monster.transform.position = new Vector3 (8.5f, -1.5f, 0);
	//	monster.transform.parent = spawnPos;

		monster.AddComponent ("Rigidbody2D");
		monster.GetComponent<Rigidbody2D> ().isKinematic = true;
		monster.GetComponent<Rigidbody2D> ().gravityScale = 0;
		monster.AddComponent ("monsterData");
		monster.GetComponent<monsterData> ().create (mData.CreateMonster (Id));
		
		string fileName = data.fileName;
		string finalPath;
		finalPath = string.Format("Texture/Enemy/{0}", fileName);
		monster.AddComponent ("SpriteRenderer");
		
		SpriteRenderer monRenderer = (SpriteRenderer)monster.GetComponent ("SpriteRenderer");
		//Sprite mysprite = Resources.Load<Sprite>("Texture/Enemy/slime");
		Sprite mysprite = Resources.Load<Sprite>(finalPath);
		monRenderer.sprite = mysprite;
		
		monster.AddComponent ("BoxCollider2D");
		monster.GetComponent<BoxCollider2D> ().isTrigger = true;


	}
}
