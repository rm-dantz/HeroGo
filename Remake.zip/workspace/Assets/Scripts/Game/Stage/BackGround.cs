﻿using UnityEngine;
using System.Collections;

public class BackGround : MonoBehaviour 
{
	float speed = 5f; // second per 5meter
	float resetDistance; 
	float initialDistance;
    public Vector3 returnPos;


	// Use this for initialization
	void Awake()
    {
        useGUILayout = false;
		initialDistance = gameObject.transform.position.x;
		resetDistance = gameObject.transform.position.x - 18f;
        returnPos = new Vector3(initialDistance, transform.position.y, transform.position.z);
	}
	
	// Update is called once per frame
	void Update ()  
	{
        MovingMap();
	}  

    void MovingMap()
    {
        float move = speed * Time.deltaTime;
        gameObject.transform.Translate(Vector3.left * move, Space.World);
        if (transform.position.x < resetDistance)
        {
            transform.position = returnPos;
        }  
    }
}
